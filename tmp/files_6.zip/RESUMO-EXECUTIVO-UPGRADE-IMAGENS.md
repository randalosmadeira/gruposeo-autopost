# 📋 RESUMO EXECUTIVO: UPGRADE DE AGENTES DE IA

## 🎯 VISÃO GERAL DO UPGRADE

Este documento resume o upgrade avançado proposto para o sistema **ContentFactory RDM / GrupoSEO AutoPost**, focando em dois agentes críticos:

1. **Agente Reescritor de Notícias** - Com análise de tom emocional e decisão inteligente de imagem
2. **Agente Criador de Imagens** - Com gatilhos emocionais e geração de caricaturas

---

## 🔥 PRINCIPAIS FEATURES DO UPGRADE

### 1. Sistema de Gatilhos Emocionais (11 gatilhos)

| Gatilho | Uso | Estilo de Imagem |
|---------|-----|------------------|
| 😐 **SÉRIO** | Notícias graves, mortes | Fotografia documental |
| 😂 **HUMOR** | Gafes, virais, memes | Caricatura colorida |
| 😰 **PREOCUPAÇÃO** | Alertas, riscos | Fotografia dramática |
| 😡 **REVOLTA** | Escândalos, corrupção | Caricatura contundente |
| 😢 **ANGÚSTIA** | Tragédias, perdas | Fotografia melancólica |
| 😏 **SARCASMO** | Ironias, contradições | Caricatura irônica |
| 🎭 **SÁTIRA** | Crítica política/social | Cartoon editorial |
| 😊 **FELICIDADE** | Vitórias, conquistas | Fotografia vibrante |
| 🎉 **COMEMORAÇÃO** | Festas, marcos | Fotografia festiva |
| 🤔 **DÚVIDAS** | Investigações, teorias | Arte conceitual |
| 🔮 **MISTÉRIO** | Casos sem resposta | Arte noir/enigmática |

### 2. Regras de Decisão de Imagem

```
SE gatilho = SÉRIO/ANGÚSTIA + imagem original de qualidade
   → REUTILIZAR imagem original (respeito, credibilidade)

SE gatilho = HUMOR/SARCASMO/SÁTIRA/REVOLTA
   → CRIAR CARICATURA editorial (engajamento)

SE gatilho = MISTÉRIO/DÚVIDAS
   → CRIAR ARTE CONCEITUAL (atmosfera sugestiva)

SENÃO
   → GERAR IMAGEM padrão com tom emocional
```

### 3. Análise Híbrida de Tom

- **Camada 1: Keywords** (gratuita, instantânea)
  - Analisa 100+ palavras-chave mapeadas para gatilhos
  - Confiança > 85% = usa direto

- **Camada 2: IA** (custo baixo, quando necessário)
  - Análise profunda com Gemini/Claude
  - Só acionada se keywords têm baixa confiança

---

## 📁 ARQUIVOS ENTREGUES

### Documentação
| Arquivo | Descrição | Tamanho |
|---------|-----------|---------|
| `UPGRADE-AGENTES-IA-IMAGENS-EMOCAO.md` | Documentação técnica completa | 46KB |

### Código TypeScript (prontos para Supabase)
| Arquivo | Descrição | Linhas |
|---------|-----------|--------|
| `emotional-triggers-config.ts` | Tipos e configuração dos 11 gatilhos | ~600 |
| `emotional-analyzer.ts` | Analisador de tom (keywords + IA) | ~350 |
| `caricature-prompt-builder.ts` | Gerador de prompts para caricaturas | ~400 |
| `emotional-image-system.ts` | Módulo integrador principal | ~350 |

---

## 🚀 INSTRUÇÕES DE IMPLEMENTAÇÃO

### Passo 1: Copiar arquivos para o projeto

```bash
# Na raiz do projeto gruposeo-autopost
cp EMOTIONAL-IMAGE-SYSTEM/*.ts supabase/functions/_shared/emotional/
```

### Passo 2: Atualizar rewrite-news/index.ts

```typescript
// Adicionar imports
import { createEmotionalImageSystem } from '../_shared/emotional/emotional-image-system.ts';
import { generateGeminiImage, callAI } from '../_shared/gemini.ts';

// Criar instância do sistema
const emotionalSystem = createEmotionalImageSystem({
  callAI: callAI,
  generateImage: generateGeminiImage,
  defaultAspectRatio: '16:9',
  allowOriginalImageReuse: true,
});

// No processamento da notícia
const imageResult = await emotionalSystem.processNewsImage({
  title: parsedNews.title,
  content: parsedNews.content,
  sourceName: sourceName,
  originalImageUrl: originalImageUrl, // Se disponível
});

// Usar resultados
const featuredImage = imageResult.imageData;
const altText = imageResult.altText;
const emotionalTrigger = imageResult.emotionalAnalysis.primaryTrigger;
```

### Passo 3: Adicionar campos no banco de dados

```sql
-- Migration para novos campos
ALTER TABLE articles ADD COLUMN IF NOT EXISTS emotional_trigger TEXT;
ALTER TABLE articles ADD COLUMN IF NOT EXISTS emotional_confidence FLOAT;
ALTER TABLE articles ADD COLUMN IF NOT EXISTS image_style TEXT;
ALTER TABLE articles ADD COLUMN IF NOT EXISTS image_source TEXT; -- 'original' ou 'generated'
```

### Passo 4: Atualizar Frontend (opcional)

```typescript
// Adicionar seletor de gatilho manual
import { getAllTriggers } from '@/lib/emotional-triggers-config';

const triggers = getAllTriggers();
// Renderizar como dropdown para override manual
```

---

## 📊 MÉTRICAS ESPERADAS

| Métrica | Antes | Depois | Melhoria |
|---------|-------|--------|----------|
| CTR das imagens | ~2% | 4-6% | +100-200% |
| Tempo na página | 45s | 90s | +100% |
| Compartilhamentos | 0.5% | 2% | +300% |
| Custo imagem (reutilização) | 100% | 70-80% | -20-30% |

---

## ⏱️ CRONOGRAMA SUGERIDO

| Fase | Duração | Entregáveis |
|------|---------|-------------|
| **Semana 1** | Core | Instalar tipos e analyzer |
| **Semana 2** | Integração | Conectar com rewrite-news |
| **Semana 3** | Testes | Testar com 50+ notícias reais |
| **Semana 4** | Frontend | Adicionar controles manuais |
| **Semana 5** | Refinamento | Ajustar prompts baseado em feedback |

---

## 🔐 CONSIDERAÇÕES DE SEGURANÇA

1. ✅ **Caricaturas genéricas** - Nunca retratos realistas de pessoas reais
2. ✅ **Respeito em tragédias** - Reutilizar imagem original quando gatilho = anguish
3. ✅ **Sem ofensas** - Humor e sátira devem ser inteligentes, não agressivos
4. ✅ **Disclaimer** - Incluir "Ilustração editorial" em caricaturas
5. ✅ **Direitos autorais** - Atribuição quando reutilizar imagem

---

## 📞 SUPORTE

Para dúvidas sobre implementação:
- Revisar documentação em `UPGRADE-AGENTES-IA-IMAGENS-EMOCAO.md`
- Analisar código em `emotional-image-system.ts` (comentários detalhados)

---

*Documento gerado por Claude para ContentFactory RDM*
*Grupo SEO Marketing - Fevereiro 2026*
