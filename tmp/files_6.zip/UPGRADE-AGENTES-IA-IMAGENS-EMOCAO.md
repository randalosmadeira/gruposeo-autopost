# 🎯 UPGRADE AVANÇADO: AGENTES DE IA PARA IMAGENS E REESCRITA DE NOTÍCIAS

## Análise do Sistema Atual (v5)

### 📊 Estado Atual

| Componente | Arquivo | Status | Gaps Identificados |
|------------|---------|--------|-------------------|
| Geração de Imagens | `generate-image/index.ts` | ✅ Funcional | Sem gatilhos emocionais, sem caricaturas |
| Reescrita de Notícias | `rewrite-news/index.ts` | ✅ Funcional | Sem reutilização de imagem origem, sem análise de tom |
| Prompts de Nicho | `prompts.ts` | ✅ Funcional | Apenas por segmento, não por emoção |
| Gemini Integration | `gemini.ts` | ✅ Funcional | Sem suporte a estilos caricatura |

---

## 🚀 PROPOSTA DE UPGRADE: SISTEMA DE GATILHOS EMOCIONAIS

### 📋 Matriz de Gatilhos Emocionais

| Gatilho | Código | Uso Principal | Estilo Visual |
|---------|--------|---------------|---------------|
| **SÉRIO** | `serious` | Notícias graves, decisões judiciais, mortes | Fotorealista, cores neutras, composição sóbria |
| **HUMOR** | `humor` | Fatos curiosos, gafes, situações cômicas | Caricatura colorida, exagero de feições |
| **PREOCUPAÇÃO** | `concern` | Alertas, riscos, ameaças | Tons escuros, expressões tensas, sombras |
| **REVOLTA/INDIGNAÇÃO** | `outrage` | Injustiças, escândalos, corrupção | Caricatura com exagero dramático, vermelho |
| **ANGÚSTIA** | `anguish` | Tragédias, perdas, crises | Tons frios, azul/cinza, expressões de dor |
| **SARCASMO** | `sarcasm` | Ironias políticas, contradições | Caricatura satírica, elementos absurdos |
| **SÁTIRA** | `satire` | Crítica social, política | Estilo editorial cartoon, símbolos exagerados |
| **FELICIDADE** | `happiness` | Conquistas, vitórias, celebrações | Cores vibrantes, amarelo/laranja, sorrisos |
| **COMEMORAÇÃO** | `celebration` | Eventos festivos, marcos históricos | Confetes, fogos, cores festivas |
| **DÚVIDAS/INCERTEZAS** | `doubt` | Especulações, teorias, investigações | Tons neutros, interrogações visuais |
| **MISTÉRIO** | `mystery` | Casos sem resposta, enigmas | Sombras, silhuetas, elementos ocultos |

---

## 🏗️ ARQUITETURA PROPOSTA

```
┌─────────────────────────────────────────────────────────────────┐
│                    FLUXO DE REESCRITA DE NOTÍCIAS               │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  1. Entrada da Notícia                                          │
│     ├── URL/Conteúdo Original                                   │
│     ├── Imagem Original (extraída automaticamente)              │
│     └── Metadados (título, fonte, data)                         │
│                                                                 │
│  2. Agente Analisador de Tom Emocional (NOVO)                   │
│     ├── Analisa conteúdo textual                                │
│     ├── Identifica gatilho emocional predominante               │
│     ├── Sugere gatilhos secundários                             │
│     └── Retorna: {trigger: 'outrage', confidence: 0.92}         │
│                                                                 │
│  3. Decisão de Imagem (NOVO)                                    │
│     ├── REGRA 1: Se imagem original disponível E                │
│     │            gatilho = 'serious' → REUTILIZAR               │
│     ├── REGRA 2: Se gatilho = 'humor|satire|sarcasm|outrage'    │
│     │            → CRIAR CARICATURA                             │
│     ├── REGRA 3: Se gatilho = 'mystery|doubt'                   │
│     │            → CRIAR IMAGEM CONCEITUAL                      │
│     └── REGRA 4: Demais casos → Gerar imagem padrão             │
│                                                                 │
│  4. Agente Gerador de Imagem Emocional (NOVO)                   │
│     ├── Recebe: {trigger, content, context}                     │
│     ├── Aplica estilo visual do gatilho                         │
│     ├── Gera prompt otimizado para emoção                       │
│     └── Retorna: imagem + alt text emocional                    │
│                                                                 │
│  5. Reescrita com Tom Alinhado                                  │
│     ├── Ajusta vocabulário ao gatilho                           │
│     ├── Mantém consistência texto ↔ imagem                      │
│     └── Gera CTAs emocionais apropriados                        │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

---

## 📝 IMPLEMENTAÇÃO TÉCNICA

### 1. Interface de Tipos Estendida

```typescript
// types/emotional-triggers.ts

export type EmotionalTrigger = 
  | 'serious'      // Sério - notícias graves
  | 'humor'        // Humor - fatos curiosos
  | 'concern'      // Preocupação - alertas
  | 'outrage'      // Revolta/Indignação - escândalos
  | 'anguish'      // Angústia - tragédias
  | 'sarcasm'      // Sarcasmo - ironias
  | 'satire'       // Sátira - crítica social
  | 'happiness'    // Felicidade - conquistas
  | 'celebration'  // Comemoração - marcos
  | 'doubt'        // Dúvidas - especulações
  | 'mystery';     // Mistério - casos sem resposta

export type ImageStyle = 
  | 'photorealistic'  // Fotografia realista
  | 'caricature'      // Caricatura editorial
  | 'cartoon'         // Cartoon estilizado
  | 'conceptual'      // Arte conceitual
  | 'dramatic';       // Fotografia dramática

export interface EmotionalAnalysis {
  primaryTrigger: EmotionalTrigger;
  confidence: number;           // 0-1
  secondaryTriggers: EmotionalTrigger[];
  suggestedStyle: ImageStyle;
  toneKeywords: string[];       // Palavras-chave do tom
  emotionalIntensity: 'low' | 'medium' | 'high';
}

export interface ImageDecision {
  action: 'reuse_original' | 'create_caricature' | 'create_conceptual' | 'generate_new';
  reason: string;
  originalImageUrl?: string;
  style: ImageStyle;
  trigger: EmotionalTrigger;
}

export interface CaricaturePrompt {
  basePrompt: string;
  styleModifiers: string[];
  emotionalElements: string[];
  colorPalette: string[];
  composition: string;
  restrictions: string[];
}
```

### 2. Configuração de Gatilhos Emocionais

```typescript
// config/emotional-triggers-config.ts

export const EMOTIONAL_TRIGGER_CONFIG: Record<EmotionalTrigger, {
  label: string;
  description: string;
  suggestedStyle: ImageStyle;
  colorPalette: string[];
  visualElements: string[];
  promptModifiers: string[];
  headlines: string[];           // Palavras típicas em manchetes
  vocabularyTone: string[];      // Tom do vocabulário
  ctaStyle: string;              // Estilo de CTA apropriado
}> = {
  
  serious: {
    label: 'Sério',
    description: 'Notícias graves, decisões importantes, falecimentos',
    suggestedStyle: 'photorealistic',
    colorPalette: ['#2C3E50', '#34495E', '#7F8C8D', '#BDC3C7', '#ECF0F1'],
    visualElements: [
      'composição sóbria e equilibrada',
      'iluminação natural neutra',
      'fundo limpo e profissional',
      'sem elementos decorativos',
      'foco central no assunto'
    ],
    promptModifiers: [
      'fotografia jornalística profissional',
      'estilo documental',
      'tons neutros e sóbrios',
      'composição respeitosa',
      'alta qualidade editorial'
    ],
    headlines: ['morre', 'falece', 'decide', 'condena', 'determina', 'proíbe', 'anuncia'],
    vocabularyTone: ['formal', 'respeitoso', 'objetivo', 'preciso'],
    ctaStyle: 'Saiba mais sobre este importante acontecimento'
  },

  humor: {
    label: 'Humor',
    description: 'Fatos curiosos, gafes, situações cômicas',
    suggestedStyle: 'caricature',
    colorPalette: ['#F39C12', '#E74C3C', '#3498DB', '#2ECC71', '#9B59B6'],
    visualElements: [
      'exagero de expressões faciais',
      'proporções distorcidas humorísticas',
      'elementos cartoon',
      'cores vibrantes e saturadas',
      'composição dinâmica e divertida'
    ],
    promptModifiers: [
      'caricatura editorial cômica',
      'estilo cartoon humorístico',
      'expressões exageradas e engraçadas',
      'cores vivas e alegres',
      'elementos de humor visual'
    ],
    headlines: ['hilário', 'inacreditável', 'bizarro', 'curioso', 'gafe', 'viraliza', 'meme'],
    vocabularyTone: ['leve', 'descontraído', 'irônico', 'bem-humorado'],
    ctaStyle: 'Você não vai acreditar no que aconteceu!'
  },

  concern: {
    label: 'Preocupação',
    description: 'Alertas, riscos, ameaças, avisos importantes',
    suggestedStyle: 'dramatic',
    colorPalette: ['#E67E22', '#D35400', '#C0392B', '#7F8C8D', '#2C3E50'],
    visualElements: [
      'iluminação dramática com sombras',
      'tons quentes de alerta (laranja/amarelo)',
      'composição que transmite tensão',
      'foco em elementos de risco',
      'atmosfera de urgência'
    ],
    promptModifiers: [
      'fotografia dramática de alerta',
      'iluminação que transmite urgência',
      'tons de aviso (laranja/amarelo)',
      'composição tensa',
      'atmosfera de preocupação'
    ],
    headlines: ['alerta', 'risco', 'perigo', 'ameaça', 'cuidado', 'aviso', 'preocupa'],
    vocabularyTone: ['urgente', 'cauteloso', 'preventivo', 'informativo'],
    ctaStyle: 'Proteja-se: veja o que você precisa saber'
  },

  outrage: {
    label: 'Revolta / Indignação',
    description: 'Injustiças, escândalos, corrupção, abusos',
    suggestedStyle: 'caricature',
    colorPalette: ['#C0392B', '#E74C3C', '#2C3E50', '#1A1A2E', '#FF6B6B'],
    visualElements: [
      'caricatura com exagero dramático',
      'expressões de indignação/raiva',
      'elementos simbólicos de injustiça',
      'vermelho como cor dominante',
      'contraste forte luz/sombra'
    ],
    promptModifiers: [
      'caricatura política editorial',
      'estilo indignado e crítico',
      'cores fortes com vermelho dominante',
      'expressões de revolta exageradas',
      'símbolos de corrupção ou injustiça'
    ],
    headlines: ['escândalo', 'corrupção', 'absurdo', 'vergonha', 'denuncia', 'acusa', 'fraude'],
    vocabularyTone: ['contundente', 'crítico', 'denunciativo', 'enfático'],
    ctaStyle: 'Entenda o escândalo que revolta o país'
  },

  anguish: {
    label: 'Angústia',
    description: 'Tragédias, perdas, crises humanitárias',
    suggestedStyle: 'dramatic',
    colorPalette: ['#2C3E50', '#34495E', '#5D6D7E', '#85929E', '#AEB6BF'],
    visualElements: [
      'tons frios e melancólicos',
      'iluminação suave e difusa',
      'composição que transmite vazio',
      'expressões de tristeza',
      'atmosfera contemplativa'
    ],
    promptModifiers: [
      'fotografia emocional dramática',
      'tons frios azul/cinza',
      'iluminação melancólica',
      'composição que transmite perda',
      'atmosfera de luto ou tristeza'
    ],
    headlines: ['tragédia', 'vítimas', 'luto', 'desastre', 'crise', 'drama', 'sofrimento'],
    vocabularyTone: ['empático', 'respeitoso', 'solidário', 'sensível'],
    ctaStyle: 'Saiba como ajudar as vítimas'
  },

  sarcasm: {
    label: 'Sarcasmo',
    description: 'Ironias políticas, contradições evidentes',
    suggestedStyle: 'caricature',
    colorPalette: ['#9B59B6', '#8E44AD', '#3498DB', '#E74C3C', '#F39C12'],
    visualElements: [
      'caricatura com ironia visual',
      'elementos de contradição',
      'expressões cínicas exageradas',
      'símbolos de hipocrisia',
      'composição que expõe absurdos'
    ],
    promptModifiers: [
      'caricatura editorial sarcástica',
      'estilo irônico e cínico',
      'elementos que expõem contradições',
      'expressões de deboche visual',
      'símbolos de hipocrisia política'
    ],
    headlines: ['ironia', 'contradição', 'promete mas', 'diz uma coisa', 'ao contrário'],
    vocabularyTone: ['irônico', 'cínico', 'perspicaz', 'mordaz'],
    ctaStyle: 'A ironia que ninguém esperava ver'
  },

  satire: {
    label: 'Sátira',
    description: 'Crítica social e política através do humor',
    suggestedStyle: 'cartoon',
    colorPalette: ['#2ECC71', '#3498DB', '#E74C3C', '#F39C12', '#9B59B6'],
    visualElements: [
      'estilo editorial de charge',
      'símbolos políticos exagerados',
      'metáforas visuais claras',
      'elementos de crítica social',
      'composição de revista/jornal'
    ],
    promptModifiers: [
      'charge política editorial',
      'estilo de cartunista de jornal',
      'metáforas visuais de crítica social',
      'símbolos políticos estilizados',
      'composição de sátira clássica'
    ],
    headlines: ['enquanto isso', 'governo', 'político', 'eleição', 'decisão polêmica'],
    vocabularyTone: ['satírico', 'crítico', 'perspicaz', 'inteligente'],
    ctaStyle: 'A charge que resume a situação política'
  },

  happiness: {
    label: 'Felicidade',
    description: 'Conquistas, vitórias, boas notícias',
    suggestedStyle: 'photorealistic',
    colorPalette: ['#F1C40F', '#F39C12', '#E67E22', '#27AE60', '#3498DB'],
    visualElements: [
      'iluminação brilhante e otimista',
      'cores quentes e vibrantes',
      'expressões de alegria',
      'composição expansiva e aberta',
      'elementos de sucesso e conquista'
    ],
    promptModifiers: [
      'fotografia vibrante e otimista',
      'iluminação dourada de sucesso',
      'cores quentes e alegres',
      'expressões de vitória e felicidade',
      'atmosfera de celebração'
    ],
    headlines: ['conquista', 'vitória', 'sucesso', 'aprovado', 'recorde', 'histórico', 'inédito'],
    vocabularyTone: ['otimista', 'entusiasmado', 'comemorativo', 'positivo'],
    ctaStyle: 'Celebre essa conquista histórica!'
  },

  celebration: {
    label: 'Comemoração',
    description: 'Eventos festivos, aniversários, marcos históricos',
    suggestedStyle: 'photorealistic',
    colorPalette: ['#F1C40F', '#E74C3C', '#3498DB', '#2ECC71', '#9B59B6'],
    visualElements: [
      'elementos festivos (confetes, balões)',
      'cores vibrantes e festivas',
      'iluminação de celebração',
      'composição alegre e dinâmica',
      'símbolos de festa e união'
    ],
    promptModifiers: [
      'fotografia de celebração festiva',
      'elementos de festa coloridos',
      'confetes e decoração comemorativa',
      'atmosfera de alegria coletiva',
      'iluminação vibrante de evento'
    ],
    headlines: ['comemora', 'aniversário', 'marca', 'celebra', 'festeja', 'homenagem'],
    vocabularyTone: ['festivo', 'alegre', 'comemorativo', 'entusiasmado'],
    ctaStyle: 'Participe dessa celebração histórica!'
  },

  doubt: {
    label: 'Dúvidas / Incertezas',
    description: 'Especulações, teorias, investigações em andamento',
    suggestedStyle: 'conceptual',
    colorPalette: ['#7F8C8D', '#95A5A6', '#BDC3C7', '#34495E', '#2C3E50'],
    visualElements: [
      'elementos de interrogação visual',
      'composição ambígua',
      'tons neutros e indefinidos',
      'sombras parciais',
      'foco suave, desfocado em partes'
    ],
    promptModifiers: [
      'arte conceitual de questionamento',
      'elementos visuais de dúvida',
      'composição ambígua e reflexiva',
      'tons neutros de incerteza',
      'símbolos de interrogação sutis'
    ],
    headlines: ['pode ser', 'será que', 'investiga', 'suspeita', 'apura', 'dúvidas', 'incerto'],
    vocabularyTone: ['cauteloso', 'questionador', 'analítico', 'ponderado'],
    ctaStyle: 'Entenda os fatos e tire suas conclusões'
  },

  mystery: {
    label: 'Mistério',
    description: 'Casos sem resposta, enigmas, desaparecimentos',
    suggestedStyle: 'conceptual',
    colorPalette: ['#1A1A2E', '#16213E', '#0F3460', '#533483', '#2C2C54'],
    visualElements: [
      'sombras profundas e misteriosas',
      'elementos parcialmente ocultos',
      'silhuetas enigmáticas',
      'névoa ou blur intencional',
      'composição que esconde mais do que revela'
    ],
    promptModifiers: [
      'arte conceitual de mistério',
      'sombras e silhuetas enigmáticas',
      'elementos parcialmente revelados',
      'atmosfera de suspense noir',
      'composição que sugere o oculto'
    ],
    headlines: ['mistério', 'enigma', 'desaparece', 'sem explicação', 'ninguém sabe', 'caso'],
    vocabularyTone: ['intrigante', 'misterioso', 'investigativo', 'suspense'],
    ctaStyle: 'O mistério que ainda não tem resposta'
  }
};

// Mapeamento de palavras-chave para gatilhos
export const TRIGGER_KEYWORDS: Record<string, EmotionalTrigger[]> = {
  // Palavras que indicam tom sério
  'morre': ['serious', 'anguish'],
  'falece': ['serious', 'anguish'],
  'morte': ['serious', 'anguish'],
  'óbito': ['serious', 'anguish'],
  'condena': ['serious', 'outrage'],
  'prisão': ['serious', 'outrage'],
  'sentença': ['serious'],
  
  // Palavras que indicam humor
  'hilário': ['humor'],
  'bizarro': ['humor', 'mystery'],
  'inacreditável': ['humor', 'outrage'],
  'viraliza': ['humor', 'happiness'],
  'meme': ['humor', 'satire'],
  'gafe': ['humor', 'sarcasm'],
  
  // Palavras que indicam preocupação
  'alerta': ['concern'],
  'risco': ['concern'],
  'perigo': ['concern', 'anguish'],
  'ameaça': ['concern', 'outrage'],
  'cuidado': ['concern'],
  
  // Palavras que indicam revolta
  'escândalo': ['outrage'],
  'corrupção': ['outrage', 'satire'],
  'fraude': ['outrage'],
  'absurdo': ['outrage', 'sarcasm'],
  'vergonha': ['outrage'],
  'denúncia': ['outrage', 'serious'],
  
  // Palavras que indicam felicidade/comemoração
  'vitória': ['happiness', 'celebration'],
  'conquista': ['happiness'],
  'recorde': ['happiness', 'celebration'],
  'sucesso': ['happiness'],
  'aprovado': ['happiness'],
  'comemora': ['celebration'],
  'celebra': ['celebration'],
  
  // Palavras que indicam mistério/dúvida
  'mistério': ['mystery'],
  'enigma': ['mystery'],
  'desaparece': ['mystery', 'anguish'],
  'investiga': ['doubt', 'mystery'],
  'suspeita': ['doubt'],
  'incerto': ['doubt'],
  
  // Palavras que indicam sátira/sarcasmo
  'ironia': ['sarcasm'],
  'contradição': ['sarcasm'],
  'enquanto isso': ['satire', 'sarcasm'],
  'político': ['satire', 'serious'],
};
```

---

## 🔧 CÓDIGO DE IMPLEMENTAÇÃO

### 3. Agente Analisador de Tom Emocional

```typescript
// supabase/functions/_shared/emotional-analyzer.ts

import { callAI } from './gemini.ts';
import { 
  EmotionalTrigger, 
  EmotionalAnalysis, 
  EMOTIONAL_TRIGGER_CONFIG,
  TRIGGER_KEYWORDS 
} from './emotional-triggers-config.ts';

/**
 * Analisa o conteúdo e identifica o gatilho emocional predominante
 */
export async function analyzeEmotionalTone(
  title: string,
  content: string,
  sourceName?: string
): Promise<EmotionalAnalysis> {
  
  // Pré-análise por palavras-chave (rápida e barata)
  const preAnalysis = quickKeywordAnalysis(title, content);
  
  // Se confiança alta na pré-análise, usar diretamente
  if (preAnalysis.confidence > 0.85) {
    return preAnalysis;
  }
  
  // Análise profunda com IA
  const prompt = `
Você é um especialista em análise de tom emocional para jornalismo.

Analise o seguinte conteúdo e identifique o GATILHO EMOCIONAL predominante:

**TÍTULO:** ${title}
**FONTE:** ${sourceName || 'Não informada'}
**CONTEÚDO (primeiros 1500 caracteres):**
${content.substring(0, 1500)}

---

## GATILHOS DISPONÍVEIS:

1. **serious** - Notícias graves, decisões judiciais, mortes
2. **humor** - Fatos curiosos, gafes, situações cômicas
3. **concern** - Alertas, riscos, ameaças
4. **outrage** - Injustiças, escândalos, corrupção
5. **anguish** - Tragédias, perdas, crises humanitárias
6. **sarcasm** - Ironias políticas, contradições
7. **satire** - Crítica social e política através do humor
8. **happiness** - Conquistas, vitórias, boas notícias
9. **celebration** - Eventos festivos, marcos históricos
10. **doubt** - Especulações, teorias, investigações
11. **mystery** - Casos sem resposta, enigmas

---

## RETORNE APENAS JSON:

{
  "primaryTrigger": "código_do_gatilho",
  "confidence": 0.0 a 1.0,
  "secondaryTriggers": ["gatilho2", "gatilho3"],
  "emotionalIntensity": "low|medium|high",
  "toneKeywords": ["palavra1", "palavra2", "palavra3"],
  "reasoning": "Breve explicação do porquê"
}
`;

  try {
    const response = await callAI([
      { role: 'user', content: prompt }
    ], { maxTokens: 500, temperature: 0.3 });
    
    const parsed = JSON.parse(response.match(/\{[\s\S]*\}/)?.[0] || '{}');
    
    const config = EMOTIONAL_TRIGGER_CONFIG[parsed.primaryTrigger as EmotionalTrigger];
    
    return {
      primaryTrigger: parsed.primaryTrigger || 'serious',
      confidence: parsed.confidence || 0.7,
      secondaryTriggers: parsed.secondaryTriggers || [],
      suggestedStyle: config?.suggestedStyle || 'photorealistic',
      toneKeywords: parsed.toneKeywords || [],
      emotionalIntensity: parsed.emotionalIntensity || 'medium',
    };
  } catch (error) {
    console.error('Emotional analysis error:', error);
    return preAnalysis; // Fallback para pré-análise
  }
}

/**
 * Análise rápida por palavras-chave
 */
function quickKeywordAnalysis(title: string, content: string): EmotionalAnalysis {
  const fullText = `${title} ${content}`.toLowerCase();
  
  const triggerScores: Record<EmotionalTrigger, number> = {
    serious: 0, humor: 0, concern: 0, outrage: 0, anguish: 0,
    sarcasm: 0, satire: 0, happiness: 0, celebration: 0, doubt: 0, mystery: 0
  };
  
  // Calcular scores baseado em palavras-chave
  for (const [keyword, triggers] of Object.entries(TRIGGER_KEYWORDS)) {
    if (fullText.includes(keyword.toLowerCase())) {
      triggers.forEach((trigger, index) => {
        // Primeiro trigger na lista tem peso maior
        triggerScores[trigger] += (2 - index * 0.5);
      });
    }
  }
  
  // Encontrar trigger com maior score
  let primaryTrigger: EmotionalTrigger = 'serious';
  let maxScore = 0;
  
  for (const [trigger, score] of Object.entries(triggerScores)) {
    if (score > maxScore) {
      maxScore = score;
      primaryTrigger = trigger as EmotionalTrigger;
    }
  }
  
  // Calcular confiança baseada na diferença de scores
  const sortedScores = Object.values(triggerScores).sort((a, b) => b - a);
  const confidence = maxScore > 0 
    ? Math.min(0.95, 0.5 + (sortedScores[0] - sortedScores[1]) * 0.15)
    : 0.5;
  
  // Triggers secundários
  const secondaryTriggers = Object.entries(triggerScores)
    .filter(([t, s]) => s > 0 && t !== primaryTrigger)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 2)
    .map(([t]) => t as EmotionalTrigger);
  
  const config = EMOTIONAL_TRIGGER_CONFIG[primaryTrigger];
  
  return {
    primaryTrigger,
    confidence,
    secondaryTriggers,
    suggestedStyle: config.suggestedStyle,
    toneKeywords: config.vocabularyTone,
    emotionalIntensity: maxScore > 4 ? 'high' : maxScore > 2 ? 'medium' : 'low',
  };
}
```

### 4. Decisor de Imagem

```typescript
// supabase/functions/_shared/image-decision.ts

import { EmotionalAnalysis, ImageDecision, EmotionalTrigger } from './emotional-triggers-config.ts';

/**
 * Decide qual ação tomar com a imagem baseado na análise emocional
 */
export function decideImageAction(
  analysis: EmotionalAnalysis,
  originalImageUrl?: string,
  hasHighQualityOriginal: boolean = false
): ImageDecision {
  
  const trigger = analysis.primaryTrigger;
  
  // REGRA 1: Notícias sérias com imagem de alta qualidade - REUTILIZAR
  if (
    trigger === 'serious' && 
    originalImageUrl && 
    hasHighQualityOriginal
  ) {
    return {
      action: 'reuse_original',
      reason: 'Notícia séria com imagem original de qualidade - manter autenticidade',
      originalImageUrl,
      style: 'photorealistic',
      trigger,
    };
  }
  
  // REGRA 2: Anguish com imagem original - REUTILIZAR (respeito)
  if (
    trigger === 'anguish' && 
    originalImageUrl
  ) {
    return {
      action: 'reuse_original',
      reason: 'Notícia sensível - manter imagem original por respeito',
      originalImageUrl,
      style: 'photorealistic',
      trigger,
    };
  }
  
  // REGRA 3: Humor, Sátira, Sarcasmo, Revolta - CRIAR CARICATURA
  if (['humor', 'satire', 'sarcasm', 'outrage'].includes(trigger)) {
    return {
      action: 'create_caricature',
      reason: `Gatilho ${trigger} - criar caricatura editorial para engajamento`,
      style: trigger === 'satire' ? 'cartoon' : 'caricature',
      trigger,
    };
  }
  
  // REGRA 4: Mistério, Dúvida - CRIAR IMAGEM CONCEITUAL
  if (['mystery', 'doubt'].includes(trigger)) {
    return {
      action: 'create_conceptual',
      reason: `Gatilho ${trigger} - criar arte conceitual que sugere o desconhecido`,
      style: 'conceptual',
      trigger,
    };
  }
  
  // REGRA 5: Demais casos - GERAR NOVA IMAGEM
  return {
    action: 'generate_new',
    reason: 'Gerar imagem otimizada para o tom emocional',
    style: analysis.suggestedStyle,
    trigger,
  };
}

/**
 * Verifica qualidade da imagem original
 */
export async function checkOriginalImageQuality(
  imageUrl: string
): Promise<{ hasHighQuality: boolean; width: number; height: number }> {
  try {
    // Verificar via HEAD request os metadados
    const response = await fetch(imageUrl, { method: 'HEAD' });
    
    if (!response.ok) {
      return { hasHighQuality: false, width: 0, height: 0 };
    }
    
    const contentLength = parseInt(response.headers.get('content-length') || '0');
    
    // Imagem com mais de 100KB provavelmente tem qualidade razoável
    const hasHighQuality = contentLength > 100000;
    
    return {
      hasHighQuality,
      width: 0, // Seria necessário baixar para verificar
      height: 0,
    };
  } catch (error) {
    console.error('Error checking image quality:', error);
    return { hasHighQuality: false, width: 0, height: 0 };
  }
}
```

### 5. Gerador de Prompts para Caricaturas

```typescript
// supabase/functions/_shared/caricature-prompt-builder.ts

import { 
  EmotionalTrigger, 
  CaricaturePrompt,
  EMOTIONAL_TRIGGER_CONFIG 
} from './emotional-triggers-config.ts';

/**
 * Constrói prompt otimizado para geração de caricatura baseada no gatilho emocional
 */
export function buildCaricaturePrompt(
  trigger: EmotionalTrigger,
  title: string,
  context: string,
  persons?: string[],   // Nomes de pessoas mencionadas
  entities?: string[]   // Entidades (empresas, governos, etc)
): CaricaturePrompt {
  
  const config = EMOTIONAL_TRIGGER_CONFIG[trigger];
  
  // Elementos base por gatilho
  const emotionalElements = getEmotionalElements(trigger, title);
  
  // Construir prompt base
  const basePrompt = buildBasePrompt(trigger, title, context, persons, entities);
  
  // Modificadores de estilo
  const styleModifiers = [
    ...config.promptModifiers,
    getStyleModifierByTrigger(trigger),
  ];
  
  // Paleta de cores
  const colorPalette = config.colorPalette;
  
  // Composição
  const composition = getCompositionByTrigger(trigger);
  
  // Restrições importantes
  const restrictions = [
    'NÃO incluir texto, letras ou palavras na imagem',
    'NÃO incluir logotipos ou marcas registradas',
    'NÃO criar rostos reconhecíveis de pessoas reais (exceto se caricatura)',
    'NÃO incluir conteúdo ofensivo, violento ou sexualmente explícito',
    'NÃO criar imagens que possam ser confundidas com fotografias reais',
    trigger === 'serious' || trigger === 'anguish' 
      ? 'Manter tom respeitoso e sóbrio' 
      : '',
  ].filter(Boolean);
  
  return {
    basePrompt,
    styleModifiers,
    emotionalElements,
    colorPalette,
    composition,
    restrictions,
  };
}

function buildBasePrompt(
  trigger: EmotionalTrigger,
  title: string,
  context: string,
  persons?: string[],
  entities?: string[]
): string {
  const config = EMOTIONAL_TRIGGER_CONFIG[trigger];
  
  // Tipo de arte baseado no estilo sugerido
  const artType = {
    'caricature': 'caricatura editorial de alta qualidade estilo charge de jornal',
    'cartoon': 'ilustração cartoon estilizada para editorial',
    'conceptual': 'arte conceitual abstrata com elementos simbólicos',
    'dramatic': 'fotografia artística dramática com iluminação expressiva',
    'photorealistic': 'fotografia profissional editorial de alta qualidade',
  }[config.suggestedStyle];
  
  // Elementos visuais do gatilho
  const visualDesc = config.visualElements.slice(0, 3).join(', ');
  
  let prompt = `Crie uma ${artType} para ilustrar a seguinte notícia:

TÍTULO: "${title}"

CONTEXTO: ${context.substring(0, 300)}

ESTILO VISUAL:
- ${visualDesc}
- Paleta de cores: ${config.colorPalette.join(', ')}
`;

  // Adicionar elementos específicos para caricaturas
  if (config.suggestedStyle === 'caricature' || config.suggestedStyle === 'cartoon') {
    if (persons && persons.length > 0) {
      prompt += `
PERSONAGENS (representar de forma caricata genérica, NÃO retratos realistas):
- ${persons.slice(0, 2).join('\n- ')}
`;
    }
    
    if (entities && entities.length > 0) {
      prompt += `
ENTIDADES (representar simbolicamente):
- ${entities.slice(0, 2).join('\n- ')}
`;
    }
  }
  
  return prompt;
}

function getEmotionalElements(trigger: EmotionalTrigger, title: string): string[] {
  const elements: Record<EmotionalTrigger, string[]> = {
    serious: [
      'Expressão neutra e composta',
      'Postura formal e respeitosa',
      'Ambiente profissional'
    ],
    humor: [
      'Expressões exageradas e cômicas',
      'Elementos de surpresa visual',
      'Proporções distorcidas para efeito cômico'
    ],
    concern: [
      'Expressões de apreensão',
      'Elementos de alerta (símbolos de atenção)',
      'Atmosfera tensa'
    ],
    outrage: [
      'Expressões de indignação exageradas',
      'Elementos simbólicos de corrupção ou injustiça',
      'Contraste dramático'
    ],
    anguish: [
      'Tons sombrios e melancólicos',
      'Atmosfera contemplativa',
      'Elementos que sugerem perda'
    ],
    sarcasm: [
      'Expressões de deboche visual',
      'Elementos contraditórios lado a lado',
      'Ironia visual clara'
    ],
    satire: [
      'Símbolos políticos estilizados',
      'Metáforas visuais claras',
      'Estilo de charge clássica'
    ],
    happiness: [
      'Expressões radiantes',
      'Cores vibrantes e quentes',
      'Elementos de celebração'
    ],
    celebration: [
      'Elementos festivos',
      'Cores vibrantes',
      'Atmosfera de comemoração'
    ],
    doubt: [
      'Elementos de interrogação',
      'Composição ambígua',
      'Sombras parciais'
    ],
    mystery: [
      'Silhuetas enigmáticas',
      'Elementos parcialmente ocultos',
      'Atmosfera noir'
    ]
  };
  
  return elements[trigger] || elements.serious;
}

function getStyleModifierByTrigger(trigger: EmotionalTrigger): string {
  const modifiers: Record<EmotionalTrigger, string> = {
    serious: 'Estilo jornalístico documental, iluminação natural',
    humor: 'Estilo cartoon exagerado, cores saturadas e vibrantes',
    concern: 'Iluminação dramática com sombras, tons de alerta',
    outrage: 'Estilo charge política contundente, vermelho dominante',
    anguish: 'Tons dessaturados, atmosfera melancólica, luz difusa',
    sarcasm: 'Estilo irônico editorial, elementos contraditórios visuais',
    satire: 'Estilo de cartunista político clássico, metáforas visuais',
    happiness: 'Cores quentes e brilhantes, iluminação otimista',
    celebration: 'Elementos festivos coloridos, atmosfera de evento',
    doubt: 'Composição que sugere questionamento, elementos indefinidos',
    mystery: 'Atmosfera noir, sombras profundas, elementos ocultos'
  };
  
  return modifiers[trigger];
}

function getCompositionByTrigger(trigger: EmotionalTrigger): string {
  const compositions: Record<EmotionalTrigger, string> = {
    serious: 'Composição centralizada, equilibrada, regra dos terços',
    humor: 'Composição dinâmica, ângulos inusitados, elementos de surpresa',
    concern: 'Foco central com elementos de tensão nas bordas',
    outrage: 'Composição dramática, ângulo baixo para impor presença',
    anguish: 'Composição que sugere vazio, espaço negativo intencional',
    sarcasm: 'Elementos contraditórios lado a lado para evidenciar ironia',
    satire: 'Composição de charge clássica, símbolos em destaque',
    happiness: 'Composição expansiva e aberta, elementos ascendentes',
    celebration: 'Composição festiva, elementos que sugerem movimento',
    doubt: 'Composição ambígua, elementos parcialmente visíveis',
    mystery: 'Composição que esconde mais do que revela, foco em sombras'
  };
  
  return compositions[trigger];
}

/**
 * Gera o prompt final formatado para a API de imagem
 */
export function generateFinalImagePrompt(caricaturePrompt: CaricaturePrompt): string {
  return `${caricaturePrompt.basePrompt}

DIREÇÃO ARTÍSTICA:
${caricaturePrompt.styleModifiers.map(m => `- ${m}`).join('\n')}

ELEMENTOS EMOCIONAIS:
${caricaturePrompt.emotionalElements.map(e => `- ${e}`).join('\n')}

PALETA DE CORES: ${caricaturePrompt.colorPalette.join(', ')}

COMPOSIÇÃO: ${caricaturePrompt.composition}

RESTRIÇÕES OBRIGATÓRIAS:
${caricaturePrompt.restrictions.map(r => `- ${r}`).join('\n')}

Formato: 16:9 landscape, alta resolução, adequado para publicação web.`;
}
```

---

## 📦 UPGRADE DO REWRITE-NEWS

### 6. Novo index.ts com Integração Emocional

```typescript
// supabase/functions/rewrite-news/index.ts (UPGRADE)

import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.38.4";
import { createLogger, createRequestId } from "../_shared/logger.ts";
import { callAI, generateGeminiImage, extractJSON } from "../_shared/gemini.ts";
import { analyzeEmotionalTone } from "../_shared/emotional-analyzer.ts";
import { decideImageAction, checkOriginalImageQuality } from "../_shared/image-decision.ts";
import { buildCaricaturePrompt, generateFinalImagePrompt } from "../_shared/caricature-prompt-builder.ts";
import { 
  JOURNALISTIC_SYSTEM_PROMPT, 
  MANDATORY_JSON_OUTPUT_INSTRUCTIONS,
  buildUserPrompt, 
  type JournalisticRewriteRequest,
  type JournalisticRewriteResponse 
} from "./prompts.ts";

const FUNCTION_NAME = "rewrite-news";

// ... (corsHeaders e código de autenticação permanecem iguais) ...

serve(async (req) => {
  const requestId = createRequestId();
  const log = createLogger(FUNCTION_NAME, requestId);
  const startTime = Date.now();

  // ... (código de auth igual) ...

  try {
    // Parse request
    const body: JournalisticRewriteRequest & { 
      userId?: string;
      originalImageUrl?: string;  // NOVO: URL da imagem original
      forceCaricature?: boolean;  // NOVO: Forçar criação de caricatura
      emotionalTrigger?: EmotionalTrigger; // NOVO: Override manual do gatilho
    } = await req.json();

    // ... (validação e auth igual) ...

    // ========================================
    // NOVO: ANÁLISE DE TOM EMOCIONAL
    // ========================================
    log.info("analyzing_emotional_tone", { title: body.sourceName });
    
    const emotionalAnalysis = body.emotionalTrigger 
      ? {
          primaryTrigger: body.emotionalTrigger,
          confidence: 1.0,
          secondaryTriggers: [],
          suggestedStyle: EMOTIONAL_TRIGGER_CONFIG[body.emotionalTrigger].suggestedStyle,
          toneKeywords: [],
          emotionalIntensity: 'medium' as const,
        }
      : await analyzeEmotionalTone(
          body.sourceName || '',
          body.sourceContent,
          body.sourceUrl
        );
    
    log.info("emotional_analysis_complete", {
      trigger: emotionalAnalysis.primaryTrigger,
      confidence: emotionalAnalysis.confidence,
      style: emotionalAnalysis.suggestedStyle,
    });

    // ========================================
    // NOVO: DECISÃO DE IMAGEM
    // ========================================
    let originalImageQuality = { hasHighQuality: false, width: 0, height: 0 };
    
    if (body.originalImageUrl) {
      originalImageQuality = await checkOriginalImageQuality(body.originalImageUrl);
      log.info("original_image_quality", originalImageQuality);
    }
    
    const imageDecision = body.forceCaricature
      ? {
          action: 'create_caricature' as const,
          reason: 'Forçado pelo usuário',
          style: 'caricature' as const,
          trigger: emotionalAnalysis.primaryTrigger,
        }
      : decideImageAction(
          emotionalAnalysis,
          body.originalImageUrl,
          originalImageQuality.hasHighQuality
        );
    
    log.info("image_decision", {
      action: imageDecision.action,
      reason: imageDecision.reason,
      style: imageDecision.style,
    });

    // ... (código de reescrita igual até a geração de imagem) ...

    // ========================================
    // NOVO: GERAÇÃO DE IMAGEM BASEADA NA DECISÃO
    // ========================================
    let featuredImage: string | null = null;
    let imagePromptUsed: string = '';

    switch (imageDecision.action) {
      case 'reuse_original':
        // Usar imagem original
        featuredImage = body.originalImageUrl || null;
        imagePromptUsed = 'Imagem original reutilizada';
        log.info("reusing_original_image", { url: body.originalImageUrl });
        break;
        
      case 'create_caricature':
      case 'create_conceptual':
        // Criar caricatura ou arte conceitual com prompt emocional
        const caricaturePrompt = buildCaricaturePrompt(
          imageDecision.trigger,
          parsed.seo?.metaTitle || body.sourceName,
          body.sourceContent.substring(0, 500),
          parsed.internal?.tags, // Usar tags como possíveis pessoas/entidades
          undefined
        );
        
        imagePromptUsed = generateFinalImagePrompt(caricaturePrompt);
        
        log.info("generating_emotional_image", {
          trigger: imageDecision.trigger,
          style: imageDecision.style,
          promptLength: imagePromptUsed.length,
        });
        
        const emotionalImageResult = await generateGeminiImage(
          imagePromptUsed, 
          { aspectRatio: "16:9" }
        );
        featuredImage = emotionalImageResult?.imageData || null;
        break;
        
      case 'generate_new':
      default:
        // Gerar imagem padrão com tom emocional
        const config = EMOTIONAL_TRIGGER_CONFIG[imageDecision.trigger];
        imagePromptUsed = `${config.promptModifiers.join('. ')}. 
          Topic: "${parsed.seo?.metaTitle || body.sourceName}". 
          ${config.visualElements.slice(0, 2).join('. ')}.
          Color palette: ${config.colorPalette.slice(0, 3).join(', ')}.`;
        
        const standardImageResult = await generateGeminiImage(
          imagePromptUsed,
          { aspectRatio: "16:9" }
        );
        featuredImage = standardImageResult?.imageData || null;
        break;
    }

    log.info("image_generation_complete", {
      hasImage: !!featuredImage,
      action: imageDecision.action,
    });

    // ========================================
    // SALVAR COM METADADOS EMOCIONAIS
    // ========================================
    const { data: article, error: dbError } = await supabaseAdmin
      .from("articles")
      .insert({
        user_id: userId,
        project_id: projectId || null,
        keyword: keyword || parsed.seo?.focusKeyword || sourceName,
        title: metaTitle,
        content: parsed.content?.html || '',
        excerpt: metaDescription,
        slug: parsed.seo?.slug || '',
        featured_image_url: featuredImage,
        type: "blog",
        status: "draft",
        word_count: parsed.content?.wordCount || 0,
        config: {
          type: "rewrite",
          source_url: sourceUrl,
          source_name: sourceName,
          // ... demais campos ...
          
          // NOVOS CAMPOS EMOCIONAIS
          emotional_trigger: emotionalAnalysis.primaryTrigger,
          emotional_confidence: emotionalAnalysis.confidence,
          emotional_secondary: emotionalAnalysis.secondaryTriggers,
          emotional_intensity: emotionalAnalysis.emotionalIntensity,
          image_decision: imageDecision.action,
          image_style: imageDecision.style,
          image_prompt: imagePromptUsed,
          original_image_url: body.originalImageUrl || null,
        },
      })
      .select()
      .single();

    // ... (resto do código igual) ...

    return new Response(
      JSON.stringify({
        success: true,
        article: {
          id: article.id,
          title: article.title,
          // ... demais campos ...
          
          // NOVOS CAMPOS NA RESPOSTA
          emotional_trigger: emotionalAnalysis.primaryTrigger,
          emotional_confidence: emotionalAnalysis.confidence,
          image_decision: imageDecision.action,
          image_style: imageDecision.style,
        },
        emotional_analysis: emotionalAnalysis,
        image_decision: imageDecision,
        request_id: requestId,
      }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
    
  } catch (error) {
    // ... tratamento de erro igual ...
  }
});
```

---

## 🎨 EXEMPLOS DE PROMPTS POR GATILHO

### Exemplo: HUMOR
```
Crie uma caricatura editorial de alta qualidade estilo charge de jornal para ilustrar:

TÍTULO: "Prefeito esquece o próprio nome em discurso e viraliza nas redes"

ESTILO VISUAL:
- Exagero de expressões faciais
- Proporções distorcidas humorísticas
- Cores vibrantes e saturadas

ELEMENTOS EMOCIONAIS:
- Expressões exageradas e cômicas
- Elementos de surpresa visual
- Proporções distorcidas para efeito cômico

PALETA DE CORES: #F39C12, #E74C3C, #3498DB, #2ECC71, #9B59B6

COMPOSIÇÃO: Composição dinâmica, ângulos inusitados, elementos de surpresa

RESTRIÇÕES:
- NÃO criar rosto reconhecível do político real
- NÃO incluir texto na imagem
- Manter tom humorístico sem ser ofensivo
```

### Exemplo: OUTRAGE (Revolta)
```
Crie uma caricatura política editorial contundente para ilustrar:

TÍTULO: "Deputado é preso com R$ 5 milhões em dinheiro vivo escondido em cueca"

ESTILO VISUAL:
- Caricatura com exagero dramático
- Expressões de indignação/ganância
- Vermelho como cor dominante

ELEMENTOS EMOCIONAIS:
- Símbolos de corrupção (notas de dinheiro, malas)
- Expressão culpada exagerada
- Contraste dramático luz/sombra

PALETA DE CORES: #C0392B, #E74C3C, #2C3E50, #1A1A2E, #FF6B6B

COMPOSIÇÃO: Composição dramática com figura central e símbolos de corrupção

RESTRIÇÕES:
- NÃO criar rosto reconhecível do político real
- Representar a figura de forma genérica mas expressiva
- Incluir elementos simbólicos de corrupção
```

### Exemplo: MYSTERY (Mistério)
```
Crie uma arte conceitual abstrata com elementos simbólicos para ilustrar:

TÍTULO: "Jovem desaparece misteriosamente após sair de festa; polícia sem pistas"

ESTILO VISUAL:
- Sombras profundas e misteriosas
- Elementos parcialmente ocultos
- Silhuetas enigmáticas

ELEMENTOS EMOCIONAIS:
- Silhueta de pessoa que se dissolve
- Névoa ou blur intencional
- Composição que esconde mais do que revela

PALETA DE CORES: #1A1A2E, #16213E, #0F3460, #533483, #2C2C54

COMPOSIÇÃO: Elementos parcialmente visíveis, foco em sombras e ausência

RESTRIÇÕES:
- NÃO criar rosto identificável
- Manter atmosfera de suspense
- Sugerir mistério sem ser macabro
```

---

## 📊 MÉTRICAS E KPIs DO UPGRADE

| Métrica | Baseline Atual | Meta Upgrade | Método de Medição |
|---------|----------------|--------------|-------------------|
| Taxa de engajamento (CTR) | ~2% | 4-6% | Analytics |
| Tempo na página | 45s | 90s | Analytics |
| Compartilhamentos | 0.5% | 2% | Social metrics |
| Precisão do tom emocional | N/A | >85% | Validação manual |
| Qualidade da caricatura | N/A | >4/5 | Rating usuário |
| Reutilização de imagem | 0% | 20-30% | Logs sistema |

---

## 🚀 ROADMAP DE IMPLEMENTAÇÃO

### Fase 1: Core (1 semana)
- [ ] Criar types `emotional-triggers.ts`
- [ ] Implementar config `emotional-triggers-config.ts`
- [ ] Criar `emotional-analyzer.ts`

### Fase 2: Decisão de Imagem (1 semana)
- [ ] Implementar `image-decision.ts`
- [ ] Criar `caricature-prompt-builder.ts`
- [ ] Testes unitários

### Fase 3: Integração (1 semana)
- [ ] Atualizar `rewrite-news/index.ts`
- [ ] Atualizar `generate-image/index.ts`
- [ ] Adicionar campos no banco de dados

### Fase 4: Frontend (1 semana)
- [ ] Seletor de gatilho emocional manual
- [ ] Preview de estilo de imagem
- [ ] Toggle para forçar caricatura

### Fase 5: Validação (1 semana)
- [ ] Testar com 50+ notícias de diferentes tipos
- [ ] Ajustar prompts baseado em feedback
- [ ] Documentar edge cases

---

## 🔐 CONSIDERAÇÕES DE SEGURANÇA E ÉTICA

1. **Não criar retratos realistas de pessoas reais** - Sempre usar caricaturas genéricas
2. **Evitar conteúdo ofensivo** - Humor e sátira devem ser inteligentes, não agressivos
3. **Respeitar tragédias** - Gatilho `anguish` deve manter tom respeitoso
4. **Disclaimer em caricaturas** - "Esta é uma representação artística/caricatura"
5. **Direitos autorais** - Se reutilizar imagem, garantir licença ou atribuição

---

*Documento gerado para ContentFactory RDM - Grupo SEO Marketing*
*Versão 2.0 - Sistema de Gatilhos Emocionais*
